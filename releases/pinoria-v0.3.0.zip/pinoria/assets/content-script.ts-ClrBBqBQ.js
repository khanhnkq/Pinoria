import{i as e,n as t,r as n,t as r}from"./core-Bo7NFLp0.js";import{n as i}from"./quick-download-yfvjd5do.js";import{c as a,l as o,o as s}from"./download-settings-BLUaF0q2.js";function c(e){return typeof e==`object`&&!!e&&e.type===`PINORIA_BOARD_DOWNLOAD_START`}var l=`
  :host {
    display: inline-flex;
    margin-inline-start: 12px;
    align-self: center;
    flex: 0 0 auto;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
  }

  *, *::before, *::after { box-sizing: border-box; }

  button {
    all: unset;
    min-height: 48px;
    min-width: 132px;
    padding: 0 18px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    border-radius: 16px;
    background: #e60023;
    color: #ffffff;
    cursor: pointer;
    font-size: 16px;
    font-weight: 700;
    line-height: 1;
    white-space: nowrap;
    transition: background-color 140ms ease, transform 140ms ease;
    -webkit-tap-highlight-color: transparent;
  }

  button:hover { background: #ad081b; }
  button:active { transform: scale(0.96); }
  button:focus-visible { outline: 3px solid #4a90e2; outline-offset: 2px; }
  button:disabled { cursor: progress; opacity: 0.92; }

  svg {
    width: 20px;
    height: 20px;
    flex: 0 0 auto;
    fill: none;
    stroke: currentColor;
    stroke-width: 2.5;
    stroke-linecap: round;
    stroke-linejoin: round;
  }

  .spinner, .check { display: none; }
  button[data-state="working"] .download,
  button[data-state="success"] .download { display: none; }
  button[data-state="working"] .spinner { display: block; animation: pk-spin 700ms linear infinite; }
  button[data-state="success"] .check { display: block; }

  @keyframes pk-spin { to { transform: rotate(360deg); } }

  @media (prefers-reduced-motion: reduce) {
    button { transition: none; }
    button[data-state="working"] .spinner { animation: none; }
  }
`;function u(e){return t(e,e.defaultView?.location.href)}function d(e){let t=u(e);return t.kind===`board`||t.kind===`section`}function f(e){return e.matches(`[data-test-id*="filter" i], button[aria-label*="filter" i], [role="button"][aria-label*="filter" i]`)||e.querySelector(`[data-test-id*="filter" i], button[aria-label*="filter" i], [role="button"][aria-label*="filter" i]`)!==null}function p(e){let t=e.querySelector(n.boardSearchInputs.join(`,`));if(!t)return;let r=t,i=t.parentElement??t;for(let e=0;e<8;e+=1){r.matches(`form, [role="search"], [data-test-id*="board-search" i], [data-test-id*="search-box" i]`)&&(i=r);let e=r.parentElement;if(!e)break;if(Array.from(e.children).filter(e=>e!==r).some(f))return r;r=e}return i}function m(e){return e.stage===`scanning`?`Đang quét ${e.scanned}`:`Đang tải ${e.completed+e.failed}/${e.total}`}function h({document:e,mutationDebounceMs:t=80,onDownloadBoard:n}){let r=e.defaultView,i,a,o,s,c,u,f=!1,h=!1,g=(e,t=e===`error`?`Thử lại`:`Tải board`)=>{!a||!o||(a.dataset.state=e,a.disabled=e===`working`,a.setAttribute(`aria-busy`,e===`working`?`true`:`false`),o.textContent=t)},_=()=>{u!==void 0&&r?.clearTimeout(u),u=r?.setTimeout(()=>g(`idle`),3e3)},v=async()=>{if(!(h||!d(e))){h=!0,u!==void 0&&r?.clearTimeout(u),g(`working`,`Đang quét 0`);try{let e=await n(e=>{g(`working`,m(e))}),t=e.failed>0?` (${e.failed} lỗi)`:``;g(`success`,`Đã tải ${e.downloaded}${t}`),_()}catch{g(`error`),_()}finally{h=!1}}},y=e=>{e.preventDefault(),e.stopImmediatePropagation(),e.stopPropagation(),v()},b=()=>{a?.removeEventListener(`click`,y,!0),i?.remove(),a=void 0,i=void 0,o=void 0},x=t=>{let n=e.createElement(`span`);n.setAttribute(`data-pinoria-board-download-host`,``);let r=n.attachShadow({mode:`open`});if(r.innerHTML=`
      <style>${l}</style>
      <button type="button" aria-label="Tải toàn bộ board bằng Pinoria" aria-busy="false" data-state="idle">
        <svg class="download" aria-hidden="true" viewBox="0 0 24 24"><path d="M12 3v12m0 0 5-5m-5 5-5-5M5 21h14" /></svg>
        <svg class="spinner" aria-hidden="true" viewBox="0 0 24 24"><path d="M20 12a8 8 0 1 1-8-8" /></svg>
        <svg class="check" aria-hidden="true" viewBox="0 0 24 24"><path d="m5 12 4 4L19 6" /></svg>
        <span aria-live="polite">Tải board</span>
      </button>
    `,a=r.querySelector(`button`)??void 0,o=r.querySelector(`button span`)??void 0,!a||!o)throw Error(`Không thể tạo nút tải board`);a.addEventListener(`click`,y,!0),i=n,t.insertAdjacentElement(`afterend`,n)},S=()=>{if(!d(e)){b();return}if(i?.isConnected)return;let t=p(e);t&&x(t)},C=()=>{c!==void 0&&r?.clearTimeout(c),c=r?.setTimeout(S,t)};return{download:v,scan:S,start:()=>{if(f)return;f=!0,S(),r?.addEventListener(`popstate`,C);let t=r?.MutationObserver;!t||!e.body||(s=new t(C),s.observe(e.body,{childList:!0,subtree:!0}))},stop:()=>{f=!1,s?.disconnect(),s=void 0,r?.removeEventListener(`popstate`,C),c!==void 0&&r?.clearTimeout(c),u!==void 0&&r?.clearTimeout(u),c=void 0,u=void 0,b()}}}function g(e){return e.status===`error`?Error(e.error??`Không thể quét board Pinterest`):e.reason===`page-changed`?Error(`Board đã thay đổi trong lúc quét`):Error(`Quá trình quét board đã dừng`)}async function _({downloadPin:e,onProgress:t,scanner:n}){let r=new Map,i=await new Promise((e,i)=>{let a=!1,o=()=>void 0,s=e=>{a||(a=!0,o(),e())};o=n.subscribe((a,o)=>{for(let e of o)r.set(e.pinId,e);if(t?.({stage:`scanning`,scanned:a.pinCount,completed:0,failed:0,total:a.pinCount}),a.status===`completed`){for(let e of n.getSnapshot().pins)r.set(e.pinId,e);s(()=>e(Array.from(r.values())))}else(a.status===`error`||a.status===`stopped`)&&s(()=>i(g(a)))});let c=n.start();for(let e of c.pins)r.set(e.pinId,e);t?.({stage:`scanning`,scanned:c.pinCount,completed:0,failed:0,total:c.pinCount}),c.status===`completed`?s(()=>e(Array.from(r.values()))):(c.status===`error`||c.status===`stopped`)&&s(()=>i(g(c)))});if(i.length===0)throw Error(`Không tìm thấy Pin nào để tải`);let a=0,o=0;for(let n of i){try{await e(n),a+=1}catch{o+=1}t?.({stage:`downloading`,scanned:i.length,completed:a,failed:o,total:i.length})}if(a===0)throw Error(`Không thể tải Pin nào trong board`);return{downloaded:a,failed:o,total:i.length}}var v=`
  :host {
    display: inline-flex;
    position: relative;
    box-sizing: border-box;
    font-family: var(--pk-control-font, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif);
    line-height: 1;
    z-index: 2147483647;
  }

  *, *::before, *::after {
    box-sizing: border-box;
  }

  .target-list {
    align-items: center;
    display: inline-flex;
    gap: 6px;
  }

  .target-control {
    display: inline-flex;
    position: relative;
  }

  button {
    all: unset;
    align-items: center;
    background: var(--pk-control-background, rgba(255, 255, 255, 0.96));
    border-radius: var(--pk-control-radius, 12px);
    box-shadow: var(--pk-control-shadow, 0 1px 4px rgba(0, 0, 0, 0.16));
    color: var(--pk-control-color, #111111);
    cursor: pointer;
    display: inline-flex;
    height: var(--pk-control-size, 40px);
    justify-content: center;
    min-height: var(--pk-control-size, 40px);
    min-width: var(--pk-control-size, 40px);
    opacity: 0;
    position: relative;
    transform: scale(0.96);
    transition: opacity 140ms ease-out, transform 140ms ease-out, background-color 140ms ease-out;
    touch-action: manipulation;
    width: var(--pk-control-size, 40px);
    -webkit-tap-highlight-color: transparent;
  }

  :host-context([data-test-id="pin"]:hover) button,
  :host-context([data-grid-item="true"]:hover) button,
  :host-context(article:hover) button,
  button:focus-visible,
  button[data-state="loading"],
  button[data-state="success"],
  button[data-state="error"] {
    opacity: 1;
    transform: scale(1);
  }

  button:hover {
    background: var(--pk-control-hover-background, #e9e9e9);
  }

  button:active {
    transform: scale(0.92);
  }

  button:focus-visible {
    outline: 3px solid var(--pk-control-focus, #4a90e2);
    outline-offset: 2px;
  }

  button[aria-busy="true"] {
    cursor: progress;
  }

  .icon {
    display: none;
    height: calc(var(--pk-control-size, 40px) * 0.5);
    width: calc(var(--pk-control-size, 40px) * 0.5);
  }

  button[data-state="idle"] .icon-download,
  button[data-state="loading"] .icon-loading,
  button[data-state="success"] .icon-success,
  button[data-state="error"] .icon-error {
    display: block;
  }

  .spinner-graphic {
    animation: pk-spin 700ms linear infinite;
    transform-box: fill-box;
    transform-origin: center;
  }

  .sr-only {
    clip: rect(0, 0, 0, 0);
    clip-path: inset(50%);
    height: 1px;
    overflow: hidden;
    position: absolute;
    white-space: nowrap;
    width: 1px;
  }

  @keyframes pk-spin {
    to { transform: rotate(360deg); }
  }

  @media (hover: none) {
    button { opacity: 1; transform: scale(1); }
  }

  @media (prefers-reduced-motion: reduce) {
    button { transition: none; }
    .spinner-graphic { animation: none; }
  }
`,y=`
  <svg class="icon icon-download" aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
    <path d="M12 3v12m0 0 5-5m-5 5-5-5M5 21h14" />
  </svg>
  <svg class="icon icon-loading" aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round">
    <g class="spinner-graphic"><path d="M21 12a9 9 0 1 1-5.3-8.2" /></g>
  </svg>
  <svg class="icon icon-success" aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
    <path d="m5 12 4 4L19 6" />
  </svg>
  <svg class="icon icon-error" aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round">
    <path d="M12 8v5m0 4h.01" /><circle cx="12" cy="12" r="9" />
  </svg>
`,b=`
  :host { color-scheme: light; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif; }
  *, *::before, *::after { box-sizing: border-box; }
  [role="alert"] {
    align-items: center; background: #111111; border-radius: 16px;
    box-shadow: 0 8px 28px rgba(0, 0, 0, 0.28); color: #ffffff;
    display: flex; font-size: 14px; font-weight: 600; gap: 10px;
    justify-content: center; line-height: 1.35; margin: 0 auto;
    max-width: 440px; min-height: 48px; padding: 12px 16px; text-align: left;
  }
  svg { color: #ff4d4f; flex: 0 0 auto; height: 20px; width: 20px; }
  @media (prefers-reduced-motion: no-preference) {
    [role="alert"] { animation: pk-toast-in 160ms ease-out; }
    @keyframes pk-toast-in {
      from { opacity: 0; transform: translateY(8px); }
      to { opacity: 1; transform: translateY(0); }
    }
  }
`,x=`
  :host { color-scheme: light; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif; }
  *, *::before, *::after { box-sizing: border-box; }
  [role="tooltip"] {
    background: #111111; border-radius: 8px; color: #ffffff;
    font-size: 12px; font-weight: 600; line-height: 1.35; max-width: 260px;
    overflow-wrap: anywhere; padding: 8px 10px; position: fixed; text-align: center;
    width: max-content;
  }
`;function S(e){let t=e.defaultView,n=e.createElement(`span`);n.setAttribute(`data-pinoria-tooltip-host`,``),Object.assign(n.style,{position:`fixed`,inset:`0`,pointerEvents:`none`,display:`none`,zIndex:`2147483647`});let r=n.attachShadow({mode:`open`});r.innerHTML=`<style>${x}</style><span role="tooltip"></span>`;let i=r.querySelector(`[role="tooltip"]`);e.body.append(n);let a;return{show:(r,o)=>{if(!i)return;a=o,i.textContent=r;let s=o.getBoundingClientRect(),c=t?.innerWidth??e.documentElement.clientWidth,l=Math.min(Math.max(s.left+s.width/2,138),Math.max(c-138,138));i.style.left=`${l}px`,s.top>=64?(i.style.top=`${s.top-8}px`,i.style.transform=`translate(-50%, -100%)`):(i.style.top=`${s.bottom+8}px`,i.style.transform=`translate(-50%, 0)`),n.style.display=`block`},hide:e=>{e&&a!==e||(a=void 0,n.style.display=`none`)},destroy:()=>n.remove()}}function C(e,t){let n=e.defaultView,r=e.createElement(`span`);r.setAttribute(`data-pinoria-feedback-host`,``),Object.assign(r.style,{position:`fixed`,left:`50%`,bottom:`24px`,width:`calc(100vw - 32px)`,maxWidth:`440px`,transform:`translateX(-50%)`,zIndex:`2147483647`,pointerEvents:`none`,display:`none`});let i=r.attachShadow({mode:`open`});i.innerHTML=`
    <style>${b}</style>
    <div role="alert" aria-live="assertive" aria-atomic="true">
      <svg aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round">
        <path d="M12 8v5m0 4h.01" /><circle cx="12" cy="12" r="9" />
      </svg>
      <span data-message></span>
    </div>
  `,e.body.append(r);let a=i.querySelector(`[data-message]`),o;return{show:e=>{o!==void 0&&n?.clearTimeout(o),a&&(a.textContent=e),r.style.display=`block`,o=n?.setTimeout(()=>{r.style.display=`none`},Math.max(t,4e3))},destroy:()=>{o!==void 0&&n?.clearTimeout(o),r.remove()}}}function w(t){let r=new Set,i=e(n.pinContainers);for(let e of t.querySelectorAll(n.pinLinks)){let t=e.closest(i);t&&r.add(t)}return Array.from(r)}function T(t){return t.querySelector(e(n.nativeActionControls))??void 0}function E(e){return`#${[1,3,5].map(t=>Number.parseInt(e.slice(t,t+2),16)).map(e=>Math.round(e*.78).toString(16).padStart(2,`0`)).join(``)}`}function D(e){return[1,3,5].map(t=>Number.parseInt(e.slice(t,t+2),16)/255).map(e=>e<=.03928?e/12.92:((e+.055)/1.055)**2.4).reduce((e,t,n)=>e+t*[.2126,.7152,.0722][n],0)>.42?`#111111`:`#ffffff`}function O(e,t,n,r){let i=e.ownerDocument.defaultView,a=t&&i?.getComputedStyle(t),o=a?.width,s=r?`36px`:o&&Number.parseFloat(o)>0?o:`40px`;e.style.setProperty(`--pk-control-size`,s),e.style.setProperty(`--pk-control-radius`,`12px`),e.style.setProperty(`--pk-control-background`,n.color),e.style.setProperty(`--pk-control-hover-background`,E(n.color)),e.style.setProperty(`--pk-control-color`,D(n.color)),e.style.setProperty(`--pk-control-shadow`,a?.boxShadow||`0 1px 4px rgba(0, 0, 0, 0.16)`),e.style.setProperty(`--pk-control-font`,a?.fontFamily||`-apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif`)}function k(e,t){let n=e.ownerDocument.defaultView,r=Array.from(e.querySelectorAll(`a[href*="/pin/"]`)).find(e=>e.querySelector(`img, picture, video, canvas`)),i=r??e,a=n?.getComputedStyle(i).position;(!a||a===`static`)&&(i.style.position=`relative`),t.dataset.placement=r?`media-overlay`:`card-overlay`,t.style.position=`absolute`,t.style.right=`12px`,t.style.bottom=`12px`,t.style.zIndex=`2147483647`,t.parentElement!==i&&i.append(t)}function A(e,t){let n=`Downloads/${t.folder}`;return e===`loading`?`Đang tải vào ${n}`:e===`success`?`Đã tải vào ${n}`:e===`error`?`Tải vào ${n} thất bại`:`Tải vào ${n}`}function j(e){return e instanceof Error&&e.message?e.message:`Không thể bắt đầu tải xuống. Hãy thử lại.`}function M(e,t,n,i,a,o,s){let c=e.ownerDocument,l=c.defaultView,u=c.createElement(`span`);u.dataset.pinoriaQuickDownloadHost=t.pinId,u.setAttribute(`data-pinoria-quick-download-host`,t.pinId);let d=u.attachShadow({mode:`open`});d.innerHTML=`
    <style>${v}</style>
    <span class="target-list" role="group" aria-label="Chọn thư mục tải xuống"></span>
    <span class="sr-only" aria-live="polite" aria-atomic="true"></span>
  `;let f=d.querySelector(`.target-list`),p=d.querySelector(`[aria-live="polite"]`);if(!f||!p)throw Error(`Unable to create quick-download controls`);let m=T(e),h=n.length>1,g=n.map(e=>{let t=c.createElement(`span`);t.className=`target-control`;let n=c.createElement(`button`);return n.type=`button`,n.dataset.state=`idle`,n.dataset.targetId=e.id,n.setAttribute(`aria-label`,A(`idle`,e)),n.innerHTML=y,O(n,m,e,h),t.append(n),f.append(t),{button:n,focused:!1,hovered:!1,message:A(`idle`,e),state:`idle`,target:e}});k(e,u),e.dataset.pinoriaControlMounted=t.pinId;let _=new Map,b=e=>{e.hovered||e.focused||e.state===`error`?o.show(e.message,e.button):o.hide(e.button)},x=(e,t,n=A(t,e.target))=>{e.state=t,e.message=n,e.button.dataset.state=t,e.button.setAttribute(`aria-label`,A(t,e.target)),e.button.setAttribute(`aria-busy`,t===`loading`?`true`:`false`),p.textContent=n,b(e)},S=n=>{let o=g.find(({target:e})=>e.id===n);if(!o||o.button.dataset.state===`loading`)return;let c=_.get(n);c!==void 0&&l?.clearTimeout(c),x(o,`loading`);let u=l?.location.href||t.context.pageUrl;i(r(e,u).pins.find(e=>e.pinId===t.pinId)??t,o.target).then(()=>x(o,`success`)).catch(e=>{let t=j(e);x(o,`error`,t),a(t)}).finally(()=>{let e=l?.setTimeout(()=>{x(o,`idle`),_.delete(n)},s);e!==void 0&&_.set(n,e)})};for(let e of g)e.button.addEventListener(`pointerenter`,()=>{e.hovered=!0,b(e)}),e.button.addEventListener(`pointerleave`,()=>{e.hovered=!1,b(e)}),e.button.addEventListener(`focus`,()=>{e.focused=!0,b(e)}),e.button.addEventListener(`blur`,()=>{e.focused=!1,b(e)}),e.button.addEventListener(`click`,t=>{t.preventDefault(),t.stopPropagation(),S(e.target.id)});return{actions:g,card:e,host:u,activate:S,destroy:()=>{for(let e of _.values())l?.clearTimeout(e);_.clear();for(let e of g)o.hide(e.button);delete e.dataset.pinoriaControlMounted,u.remove()}}}function N({document:e,downloadTargets:t=s(),onQuickDownload:n,mutationDebounceMs:i=48,feedbackDurationMs:a=1600}){let c=new Set,l=new WeakMap,u=new WeakMap,d=e.defaultView,f=o(t),p=f.length>0?f:s(),m,h,g,_,v=!1,y=t=>{e.body&&(g??=C(e,a),g.show(t))},b=e=>{for(let t of e.actions)u.delete(t.button);e.destroy(),c.delete(e)},x=()=>{let t=d?.location.href||`https://www.pinterest.com/`;for(let i of w(e)){let o=l.get(i);if(o?.host.isConnected)continue;o&&b(o);let s=r(i,t).pins[0];if(!s)continue;let d=M(i,s,p,n,y,_??=S(e),a);l.set(i,d);for(let e of d.actions)u.set(e.button,{control:d,targetId:e.target.id});c.add(d)}},T=e=>{let t=e.composedPath().map(e=>u.get(e)).find(e=>e!==void 0);t&&(e.preventDefault(),e.stopImmediatePropagation(),e.type===`click`&&t.control.activate(t.targetId))},E=[`pointerdown`,`pointerup`,`mousedown`,`mouseup`,`touchstart`,`touchend`,`click`],D=()=>{m!==void 0&&d?.clearTimeout(m),m=d?.setTimeout(x,i)};return{setDownloadTargets:e=>{let t=o(e),n=t.length>0?t:s();if(JSON.stringify(n)!==JSON.stringify(p)){p=n;for(let e of Array.from(c))b(e);x()}},start:()=>{if(v)return;v=!0;for(let e of E)d?.addEventListener(e,T,!0);x();let t=d?.MutationObserver;!t||!e.body||(h=new t(e=>{e.some(e=>Array.from(e.addedNodes).some(e=>e.nodeType!==1||!e.matches(`[data-pinoria-quick-download-host]`)))&&D()}),h.observe(e.body,{childList:!0,subtree:!0}))},stop:()=>{v=!1,h?.disconnect(),h=void 0;for(let e of E)d?.removeEventListener(e,T,!0);m!==void 0&&d?.clearTimeout(m),m=void 0;for(let e of Array.from(c))b(e);g?.destroy(),g=void 0,_?.destroy(),_=void 0},scan:x}}var P=400,F=1400,I=6e5,L=4,R=.85;function z(){return globalThis.crypto?.randomUUID?.()??`scan-${Date.now()}-${Math.random().toString(16).slice(2)}`}function B(e){return[e.kind,e.board?.ownerSlug??``,e.board?.slug??``,e.section?.slug??``].join(`:`)}function V(e){return e.kind===`board`||e.kind===`section`}function H(e){let t=e.defaultView,n=e.scrollingElement??e.documentElement;return{top:Math.max(0,t?.scrollY??n.scrollTop),height:Math.max(n.scrollHeight,e.body?.scrollHeight??0),viewport:Math.max(1,t?.innerHeight??n.clientHeight)}}function U(e){return{scanId:``,status:`idle`,pins:[],pinCount:0,duplicateCount:0,skippedCount:0,batchCount:0,scrollTop:0,scrollHeight:0,updatedAt:e}}function W(e){let t={...e};return delete t.pins,t}function G({document:e,onProgress:n,batchIntervalMs:i=P,interactionPauseMs:a=F,maxDurationMs:o=I,settleBatchCount:s=L,scrollStepRatio:c=R}){let l=e.defaultView,u=new Map,d=new Set,f=new Set,p=new Set,m=U(Date.now()),h=``,g,_=0,v=!1,y=!1,b=0,x=!1,S=()=>({...m,pins:Array.from(u.values())}),C=(e=[])=>{m.updatedAt=Date.now(),m.pinCount=u.size;let t=W(m);n?.(t,e);for(let n of p)n(t,e)},w=()=>{g!==void 0&&clearTimeout(g),g=void 0},T=(e,t,n)=>{w(),m.status=e,m.reason=t,m.error=n,C()},E=()=>{w(),!(x||m.status!==`scanning`&&m.status!==`paused`)&&(g=setTimeout(D,i))},D=()=>{if(x||m.status!==`scanning`&&m.status!==`paused`)return;let n=l?.location.href??m.context?.pageUrl??``;if(B(t(e,n))!==h){T(`stopped`,`page-changed`);return}let i=r(e,n),a=[];for(let e of i.pins)u.has(e.pinId)?d.add(e.pinId):(u.set(e.pinId,e),a.push(e));for(let e of i.skipped)f.add(`${e.pinId}:${e.reason}`);let p=H(e);if(m.batchCount+=1,m.duplicateCount=d.size,m.skippedCount=f.size,m.scrollTop=p.top,m.scrollHeight=p.height,Date.now()-(m.startedAt??0)>=o){T(`completed`,`timeout`);return}if(v||y||Date.now()<_||e.visibilityState===`hidden`){m.status=`paused`,C(a),E();return}m.status=`scanning`;let g=Math.max(0,p.height-p.viewport),S=p.top>=g-2;if(S&&a.length===0){if(b+=1,b>=s){T(`completed`,`settled`);return}}else b=0;if(!S){let e=Math.min(g,p.top+p.viewport*c);l?.scrollTo({top:e,behavior:`auto`}),m.scrollTop=e}C(a),E()},O=()=>{(m.status===`scanning`||m.status===`paused`)&&(_=Date.now()+a,m.status=`paused`,C())},k=()=>{v=!0,O()},A=()=>{v=!1,O()},j=()=>{y=!0,O()},M=()=>{y=!1,O()};return l?.addEventListener(`pointerdown`,k,{capture:!0,passive:!0}),l?.addEventListener(`pointerup`,A,{capture:!0,passive:!0}),l?.addEventListener(`pointercancel`,A,{capture:!0,passive:!0}),l?.addEventListener(`touchstart`,j,{capture:!0,passive:!0}),l?.addEventListener(`touchend`,M,{capture:!0,passive:!0}),l?.addEventListener(`touchcancel`,M,{capture:!0,passive:!0}),l?.addEventListener(`wheel`,O,{capture:!0,passive:!0}),l?.addEventListener(`keydown`,O,{capture:!0,passive:!0}),{subscribe:e=>x?()=>void 0:(p.add(e),()=>p.delete(e)),start:()=>{if(m.status===`scanning`||m.status===`paused`)return S();let n=l?.location.href??``,r=t(e,n);return u.clear(),d.clear(),f.clear(),b=0,_=0,v=!1,y=!1,m={...U(Date.now()),scanId:z(),context:r,status:`scanning`,startedAt:Date.now()},V(r)?(h=B(r),D(),S()):(T(`error`,`unsupported-page`,`Chỉ có thể quét trang board hoặc section Pinterest.`),S())},stop:()=>((m.status===`scanning`||m.status===`paused`)&&T(`stopped`,`stopped`),S()),getSnapshot:S,destroy:()=>{x=!0,w(),p.clear(),l?.removeEventListener(`pointerdown`,k,!0),l?.removeEventListener(`pointerup`,A,!0),l?.removeEventListener(`pointercancel`,A,!0),l?.removeEventListener(`touchstart`,j,!0),l?.removeEventListener(`touchend`,M,!0),l?.removeEventListener(`touchcancel`,M,!0),l?.removeEventListener(`wheel`,O,!0),l?.removeEventListener(`keydown`,O,!0)}}}if(window.__pinoriaBoardScanner||(window.__pinoriaBoardScanner=G({document})),!window.__pinoriaBoardDownloadController){let e=window.__pinoriaBoardScanner,t=h({document,onDownloadBoard:t=>_({scanner:e,downloadPin:i,onProgress:t})}),n=e=>{c(e)&&t.download()};chrome.runtime.onMessage.addListener(n),t.start(),window.__pinoriaBoardDownloadController=t,window.__pinoriaRemoveBoardDownloadMessageHandler=()=>chrome.runtime.onMessage.removeListener(n)}if(!window.__pinoriaQuickDownloadController){let e=N({document,downloadTargets:s(),onQuickDownload:(e,t)=>i(e,t.folder)});e.start(),window.__pinoriaQuickDownloadController=e;let t=()=>{a().then(t=>e.setDownloadTargets(t)).catch(()=>void 0)},n=(e,n)=>{n===`local`&&(e.downloadTargets||e.downloadFolder)&&t()};chrome.storage.onChanged.addListener(n),window.__pinoriaRemoveDownloadTargetsListener=()=>{chrome.storage.onChanged.removeListener(n)},t()}